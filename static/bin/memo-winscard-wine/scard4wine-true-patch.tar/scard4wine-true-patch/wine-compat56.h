#ifndef __WINE_COMPAT_H
// for Wine >= 5.6, which removes wine_dl* wrappers in favor of their dl* corresponding 
#define wine_dlopen(filename, flag, error, errorsize) dlopen(filename, flag)
#define wine_dlsym(handle, symbol, error, errorsize ) dlsym(handle, symbol)
#define wine_dlclose(handle, error, errorsize ) dlclose(handle)
#endif
